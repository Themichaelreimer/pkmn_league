
Pokemon.jar should be executable. Double click it I guess?

Controls:

Arrow keys - Move cursor
x - Action button. Currently only picks up and drops a pokemon.
